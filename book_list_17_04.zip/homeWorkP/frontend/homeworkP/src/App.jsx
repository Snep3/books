import React, { useState, useEffect } from "react";

export default function App() {
  const [books, setBooks] = useState([]);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [message, setMessage] = useState("");

  const fetchBooks = () => {
    fetch("http://localhost:3000/books")
      .then((res) => res.json())
      .then((data) => setBooks(data))
      .catch((err) => console.error("Failed to fetch books", err));
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const handleDelete = async (id) => {
    try {
      const response = await fetch("http://localhost:3000/delete-book", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ id })
      });

      const data = await response.json();
      setBooks(prev => prev.filter(book => book.id !== id));
      setMessage("Book deleted");
    } catch (error) {
      console.error("Error deleting book:", error);
      setMessage("Failed to delete book");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title || !author) {
      setMessage("Please fill in all fields");
      return;
    }

    setMessage("");
    const newBook = { title, author };

    try {
      const response = await fetch("http://localhost:3000/add-book", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newBook),
      });

      const result = await response.json();
      setMessage("Book added successfully");
      // console.log(result);

      setTitle("");
      setAuthor("");
      fetchBooks();
    } catch (error) {
      setMessage("Error adding book");
      console.error("Error:", error);
    }
  };

  return (
    <div>
      <h1>Books List</h1>
      <input
        type="text"
        placeholder="book name"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <input
        type="text"
        placeholder="author name"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
      />
      <button onClick={handleSubmit}>Save Book</button>

      {message && <p>{message}</p>}

      <ul>
        {books.map((book) => (
          <li key={book.id}>
            {book.title} — {book.author}
            <button onClick={() => handleDelete(book.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
