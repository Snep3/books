import React, { useState, useEffect } from "react";

export default function App() {
  const [books, setBooks] = useState([]);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [message, setMessage] = useState("");

  //loads books from the JSON 
  const fetchBooks = () => {
    fetch("http://localhost:3000/books")
      .then((res) => res.json())
      .then((data) => setBooks(data))
      .catch((err) => console.error("Failed to fetch books", err));
  };

  // calls the fetchBooks function, useEffect is used so the page loads 1 time (and not refreshes uncontrollably) 
  useEffect(() => {
    fetchBooks();
  }, []);

  // delete button logic
  const handleDelete = async (id) => {
    try {
      const response = await fetch("http://localhost:3000/delete-book", {
        // using DELETE htttp method 
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ id })
      });

      const data = await response.json();
      // deletes books by recreating the array without the selected book
      setBooks(prev => prev.filter(book => book.id !== id));
      setMessage("Book deleted");
    } catch (error) {
      console.error("Error deleting book:", error);
      setMessage("Failed to delete book");
    }
  };

  // save button function
  const handleSubmit = async (e) => {
    e.preventDefault();
    // make sure that both input fields are filled
    if (!title || !author) {
      setMessage("Please fill in all fields");
      return;
    }

    //clears the "please fill in all fields" message
    setMessage("");
    const newBook = { title, author };

    // sends the new book to the server
    try {
      const response = await fetch("http://localhost:3000/add-book", {
   // using POST htttp method 

        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newBook),
      });

      const result = await response.json();
      setMessage("Book added successfully");

      //clears the input fields and updates the page
      setTitle("");
      setAuthor("");
      fetchBooks();
    } catch (error) {
      setMessage("Error adding book");
      console.error("Error:", error);
    }
  };


  return (
    <div>
      <h1>Books List</h1>
      <input
        type="text"
        placeholder="book name"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <input
        type="text"
        placeholder="author name"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
      />
      <button onClick={handleSubmit}>Save Book</button>
      
      {/* shows the relevent message after clicking the button */}
      
      {message && <p>{message}</p>}

{/* creates the list of book, with a delete button next to each book */}
      <ul>
        {books.map((book) => (
          <li key={book.id}>
            {book.title} — {book.author}
            <button onClick={() => handleDelete(book.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
